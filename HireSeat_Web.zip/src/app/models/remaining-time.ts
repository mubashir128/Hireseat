export class RemainingTime {
    remainingDays: number = 0;
    remainingHours: number = 0;
    remainingMinutes: number = 0;
    biddingStatusChanged: boolean = false;
}