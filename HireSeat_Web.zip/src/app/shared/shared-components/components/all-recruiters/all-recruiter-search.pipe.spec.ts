import { AllRecruiterSearchPipe } from './all-recruiter-search.pipe';

describe('AllRecruiterSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new AllRecruiterSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
