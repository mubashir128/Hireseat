import { SafePdfPipe } from './safe-pdf.pipe';

describe('SafePdfPipe', () => {
  it('create an instance', () => {
    const pipe = new SafePdfPipe();
    expect(pipe).toBeTruthy();
  });
});
