import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-coaching',
  templateUrl: './recruiter-coaching.component.html',
  styleUrls: ['./recruiter-coaching.component.css']
})
export class RecruiterCoachingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
