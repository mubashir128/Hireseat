import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enterprise-navbar',
  templateUrl: './enterprise-navbar.component.html',
  styleUrls: ['./enterprise-navbar.component.css']
})
export class EnterpriseNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
