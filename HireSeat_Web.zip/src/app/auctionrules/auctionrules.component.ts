
import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-auctionrules',
  templateUrl: './auctionrules.component.html',
  styleUrls: ['./auctionrules.component.css']
})
export class AuctionrulesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
