
import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-blog-nav',
  templateUrl: './blog-nav.component.html',
  styleUrls: ['./blog-nav.component.css']
})
export class BlogNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
