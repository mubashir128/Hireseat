
import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-blog-mai',
  templateUrl: './blog-mai.component.html',
  styleUrls: ['./blog-mai.component.css']
})
export class BlogMaiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
